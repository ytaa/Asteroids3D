#include "Input.h"



Input::Input()
{
}


Input::~Input()
{
}
